package com.touchtechnology.plataformaresenhaanimes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlataformaDeResenhaSobreAnimesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlataformaDeResenhaSobreAnimesApplication.class, args);
	}

}
