package com.touchtechnology.plataformaresenhaanimes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlataformaDeResenhaSobreAnimesApplicationTests {

	@Test
	void contextLoads() {
	}

}
